import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Movie[] movies = {
            new Movie(1, "Sitaram"),
            new Movie(2, "radheshyam"),
            new Movie(3, "hariom")
        };

        Scanner sc = new Scanner(System.in);

        System.out.println("Welcome to Movie Ticket Booking!");
        System.out.println("Available Movies:");
        for (Movie movie : movies) {
            System.out.println(movie.getId() + ". " + movie.getName());
        }

        System.out.print("Enter the movie ID to book your ticket: ");
        int choice = sc.nextInt();
        boolean booked = false;
        for (Movie movie : movies) {
            if (movie.getId() == choice) {
                System.out.println("Ticket booked for: " + movie.getName());
                booked = true;
                break;
            }
        }
        if (!booked) {
            System.out.println("Invalid movie ID.");
        }
        sc.close();
    }
}